package com.fmi2023.exam01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
